-- Enable foreign key constraint
PRAGMA foreign_keys=ON;

-- New transaction block
BEGIN TRANSACTION;

-- Organiser Table : Stores the username, hashed password and email of the organiser.
CREATE TABLE IF NOT EXISTS Organisers (
    organiser_id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE
);

-- Site Settings Table : Stores the site name and site description, organiser_id is the foreign key.
CREATE TABLE IF NOT EXISTS Site_Settings (
    settings_id INTEGER PRIMARY KEY AUTOINCREMENT,
    organiser_id INTEGER NOT NULL UNIQUE,
    site_name TEXT NOT NULL,
    site_description TEXT NOT NULL,
    FOREIGN KEY (organiser_id) REFERENCES Organisers(organiser_id)
);

-- Events Table : Stores the title, description, event date, created date, updated date, published date, image path and status(draft or published) of the event. organiser_id is the foreign key.
CREATE TABLE IF NOT EXISTS Events (
    Events_id INTEGER PRIMARY KEY AUTOINCREMENT,
    organiser_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    event_date TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP, 
    published_at TEXT,
    image_path TEXT,
    status TEXT CHECK(status IN ('draft', 'published')) DEFAULT 'draft', -- Draft or published, default is draft
    FOREIGN KEY (organiser_id) REFERENCES Organisers(organiser_id)
);

-- Tickets Table : Stores the type(full or concession), quantity available and price for the tickets. event_id is the foreign key.
CREATE TABLE IF NOT EXISTS Tickets (
    Tickets_id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id INTEGER NOT NULL,
    type TEXT CHECK(type IN ('full', 'concession')) NOT NULL, -- full or concession
    quantity_available INTEGER NULL,
    price REAL NULL,
    FOREIGN KEY (event_id) REFERENCES Events(Events_id)
);

-- Bookings Table : Stores the attendee name, number of full tickets, number of concession tickets, booking date and booked by (organiser or attendee). event_id is the foreign key,
CREATE TABLE IF NOT EXISTS Bookings (
    booking_id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id INTEGER NOT NULL,
    attendee_name TEXT NOT NULL,
    full_tickets INTEGER DEFAULT 0,
    concession_tickets INTEGER DEFAULT 0,
    booking_date TEXT DEFAULT CURRENT_TIMESTAMP,
    booked_by TEXT CHECK(booked_by IN ('organiser', 'attendee')) NOT NULL, -- organiser or attendee
    FOREIGN KEY (event_id) REFERENCES Events(Events_id)
);

COMMIT;