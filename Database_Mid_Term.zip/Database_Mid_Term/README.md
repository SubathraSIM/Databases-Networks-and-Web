### CM2040 Database Networks and the Web Mid Term Assignment ###

#### Instruction To Set Up Application ####

* Requires Node.js >= 16.0.0 and npm >= 8.0.0

To start application:

1. Run ```npm install``` from the project directory to install all the node packages

2. Create the database:
   - On Mac/Linux: `npm run build-db`
   - On Windows: `npm run build-db-win`

3. Run ```npm run start``` to start serving the web app

4. Run http://localhost:3000 on browser to start the application

# Additional Libraries Used
- bcrypt: Used for hashing passwords securely before saving them to the database.
- express-sanitizer: Helps protect against cross-site scripting by sanitizing user input.
- express-session: Manages sessions to maintain login state across requests.
- express-validator: Used to validate and sanitize form inputs on the server side.
- multer: Handles image file uploads.
