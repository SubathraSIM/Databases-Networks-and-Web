// Index.js - Main entry point of the page

// Import express, bodyparser, express-session 
const express = require('express');
const app = express();
const port = 3000;
var bodyParser = require("body-parser");
const session = require('express-session');

// Create a session
app.use(session({
    secret: 'Database-Mid-Term', // Secret key
    resave: false,
    saveUninitialized: false,
    cookie: {
        maxAge: 600000
    }
}));

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine', 'ejs'); // Set to use ejs for rendering
app.use(express.static(__dirname + '/public')); // set location of static file

// SQLite Database
// Import sqlite3, enable verbose for debugging
const sqlite3 = require('sqlite3').verbose();
global.db = new sqlite3.Database('./database.db',function(err){ // global database connection using sqlite3 dataabase
    if(err){ // If error
        console.error(err); // Console log the error
        process.exit(1); // Exit the application if the connection failed
    } else {
        console.log("Database connected"); // Console log connected
        global.db.run("PRAGMA foreign_keys=ON"); // SQLite pay attention to foreign key constraints
    }
});

// Starting Layout Page
app.get('/', (req, res) => {
    res.render('layout.ejs')
});

// Route for the organiser
const organiser_router = require('./routes/organiser');
app.use('/organiser', organiser_router);

// Route for the attendee
const attendee_router = require('./routes/attendee');
app.use('/attendee', attendee_router);

// Web application listening for HTTP requests
app.listen(port, () => {
    console.log(`Server listening on port ${port}`)
});