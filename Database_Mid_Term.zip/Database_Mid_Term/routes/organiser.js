// Import Express, bcrypt, multer, path, fs and create router 
const express = require('express');
const bcrypt = require('bcrypt');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// Storage engine for Multer
const storing = multer.diskStorage({
  destination: function (req, file, cb) {
    // Upload folder to save images
    cb(null, 'public/uploads/');
  },
  // Filename formate for the files
  filename: function (req, file, cb) {
    // Organiser id
    const organiser_Id = req.session.organiserid;
    // file extension
    const extension = path.extname(file.originalname);
    // folder path
    const folder = 'public/uploads/';

    // Read files in the folder
    fs.readdir(folder, (err, files) => {
        // if got error print the error
        if (err) return cb(err);

        // Count the number of files for increment
        const timestamp = Date.now();
        // Filename format: image_organiserid_count.extension
        const filename = `image_id${organiser_Id}_${timestamp}${extension}`;
        // Save the file in the folder
        cb(null, filename);
        });
    }
});

// multer handle using storage engine
const upload = multer({ storage: storing });

// -----------------------------------------------------------------------------
// Purpose: Check login ensure organiser is logged in by checking session
// Inputs: req, res, next
// Outputs: Redirects to login page if not logged in if not continues
// -----------------------------------------------------------------------------
const check_login = (req, res, next) => {
    // If the organiser id does not exists
    if (!req.session.organiserid) {
        // Return to login page
        return res.redirect('/organiser/login');
    }
    // Continue to the next middleware if logged in
    next();
};

// -----------------------------------------------------------------------------
// GET /login
// Purpose: Show the login form
// Outputs: Renders organiser-login.ejs with no message
// -----------------------------------------------------------------------------
router.get('/login', (req, res) => {
    // Render the login page
    res.render('organiser-login', { message: null });
});

// ---------------------------------------------------------------------------------
// POST /login
// Purpose: Authenticate organiser
// Inputs: username, password from req.body
// Outputs: Redirect to organiser homepage if successful, or render login with error
// ---------------------------------------------------------------------------------
router.post('/login', (req, res) => {
    // Get the username and password from the submitted form
    const { username, password } = req.body;

    // Find the organiser by username in the database
    db.get("SELECT * FROM Organisers WHERE username = ?", [username], (error, organiser) => {
        // If error or organiser not found
        if (error || !organiser) {
            // Return to login page and show error message
            return res.status(500).render('organiser-login', { message: 'Invalid credentials' });
        }

        // Compare the password with the hashed password
        bcrypt.compare(password, organiser.password_hash, (error, resulting) => {
            // If error or password is wrong
            if (error || !resulting) {
                // Return to the login page and show error message
                return res.status(401).render('organiser-login', { message: 'Invalid credentials' });
            }

            // Set up session if username password is correct
            req.session.organiserid = organiser.organiser_id;

            // Check if site setting exist
            db.get("SELECT * FROM Site_Settings WHERE organiser_id = ?", [organiser.organiser_id], (site_setting) => {
                // If site setting not exist, insert default setting in db
                if (!site_setting) {
                    db.run(
                        "INSERT INTO Site_Settings (organiser_id, site_name, site_description) VALUES (?, ?, ?)",
                        [organiser.organiser_id, 'My New Site', 'This is your description'],
                        () => {
                            // Redirect to organiser home page
                            res.redirect('/organiser/');
                        }
                    );
                } else {
                    // If setting exist, redirect to organiser home page
                    res.redirect('/organiser/');
                }
            });
        });
    });
});

// -----------------------------------------------------------------------------
// POST /logout
// Purpose: Logout organiser and destroy session
// Outputs: Redirects to main page or render the error
// -----------------------------------------------------------------------------
router.post('/logout', check_login, (req, res) => {
    // Destroy session to logout
    req.session.destroy(error => {
        // If error
        if (error) {
            // render organiser home page with message
            return res.status(500).render('organiser-home', { message: 'Logout failed' });
        }
        // return to main layout page
        res.redirect('/');
    });
});

// -----------------------------------------------------------------------------
// GET /register
// Purpose: Render organiser registration form
// Outputs: Renders organiser-register.ejs
// -----------------------------------------------------------------------------
router.get('/register', (req, res) => {
    // Render register page
    res.render('organiser-register');
});

// --------------------------------------------------------------------------------
// POST register
// Purpose: Register a new organiser
// Inputs: username, password2, email
// Outputs: Redirect to login if it is success, or render register page with error
// --------------------------------------------------------------------------------
router.post('/register', (req, res) => {
    // get username, password, email from the form
    const { username, password2, email } = req.body;

    // Check if username already exists
    db.get("SELECT * FROM Organisers WHERE username = ?", [username], (existing) => {
        // If username exists
        if (existing) {
            // Return the organiser register page with error message
            return res.status(400).render('organiser-register', { message: 'Username already exists' });
        }

        // If username does not exist, hash the password
        bcrypt.hash(password2, 10, (error, password_hashed) => {
            // If error for hash password
            if (error) {
                // Return organiser register page with error message
                return res.status(500).render('organiser-register', { message: 'Error creating password' });
            }

            // Insert new user record into the database
            db.run(
                "INSERT INTO Organisers (username, password_hash, email) VALUES (?, ?, ?)",
                [username, password_hashed, email],
                function (error) {
                    // If error creating user
                    if (error) {
                        // Return organiser register page with error message
                        return res.status(500).render('organiser-register', { message: 'Error creating user' });
                    }

                    // Send user to the login page again to log in
                    res.redirect('/organiser/login');
                }
            );
        });
    });
});

// -----------------------------------------------------------------------------
// GET /
// Purpose: Load organiser home page with events
// Inputs: organiser ID from session
// Outputs: Renders organiser-home.ejs with event data and site settings
// -----------------------------------------------------------------------------
router.get('/', check_login, (req, res) => {
    // Organiser id from session
    const organiser_Id = req.session.organiserid;

    // get username from database
    db.get("SELECT username FROM Organisers WHERE organiser_id = ?", [organiser_Id], (error, organiser) => {
        // If error, render organiser home page and show error message
        if (error || !organiser) return res.status(500).render('organiser-home', { message: 'fail to load organiser' });
        
        // Site settings for this organiser in db
        db.get("SELECT * FROM Site_Settings WHERE organiser_id = ?", [organiser_Id], (error, site_setting) => {
            // If error, render organiser home page and show error message
            if (error || !site_setting) return res.status(500).render('organiser-home', { message: 'fail to load site settings' });

            // SQL to get draft events and its information
            const draft_events = `
                SELECT Events.*, 
                    (SELECT quantity_available FROM Tickets WHERE event_id = Events.Events_id AND type = 'full') AS full_tickets,
                    (SELECT quantity_available FROM Tickets WHERE event_id = Events.Events_id AND type = 'concession') AS concession_tickets
                FROM Events
                WHERE Events.organiser_id = ? AND Events.status = 'draft'
                ORDER BY Events.event_date
            `;

            // SQL to get published events and its information
            const published_events = `
                SELECT Events.*, 
                    (SELECT quantity_available FROM Tickets WHERE event_id = Events.Events_id AND type = 'full') AS full_tickets,
                    (SELECT quantity_available FROM Tickets WHERE event_id = Events.Events_id AND type = 'concession') AS concession_tickets
                FROM Events
                WHERE Events.organiser_id = ? AND Events.status = 'published'
                ORDER BY  Events.event_date ASC
            `;
            
            // Query to get draft event
            db.all(draft_events, [organiser_Id], (error, draft_Events) => {
                // If error, render organiser home page and show error message
                if (error) return res.status(500).render('organiser-home', { message: 'fail to load draft events' });

                // Query to get the published event
                db.all(published_events, [organiser_Id], (error, published_Events) => {
                    // If error, render organiser home page and show error message
                    if (error) return res.status(500).render('organiser-home', { message: 'fail to load published events' });

                    // Render organiser home page with all the information
                    res.render('organiser-home', {organiser,site_setting,draft_Events,published_Events});
                });
            });
        });
    });
});

// -----------------------------------------------------------------------------
// GET /site-settings
// Purpose: Show site settings page
// Inputs: organiser ID from session
// Outputs: Renders site-settings.ejs with existing or new settings
// -----------------------------------------------------------------------------
router.get('/site-settings', check_login, (req, res) => {
    // organiser id form session
    const organiser_Id = req.session.organiserid;

    // get site setting for this organiser
    db.get("SELECT * FROM Site_Settings WHERE organiser_id = ?", [organiser_Id], (error, site_setting) => {
        // If error
        if (error) {
            // Render site setting page with the error message
            return res.status(500).render('site-settings', { message: 'Database error' });
        }

        // If no settings found for organiser, insert default in db
        if (!site_setting) {
            db.run("INSERT INTO Site_Settings (organiser_id, site_name, site_description) VALUES (?, ?, ?)",
                [organiser_Id, 'My Site', 'Default description'], function (error) {
                    // If error
                    if (error) {
                        // Render site settings page with error message
                        return res.status(500).render('site-settings', { message: 'Error setting site settings' });
                    }

                    // redirect to the site settings page
                    return res.redirect('/organiser/site-settings');
                });
        } else {
            // Render site settings with the current settings if setting already exist
            res.render('site-settings', { title: 'Site Settings', site_setting });
        }
    });
});

// -----------------------------------------------------------------------------
// POST /site-settings
// Purpose: Update organiser's site settings
// Inputs: site_name, site_description
// Outputs: Redirect to organiser home page or render the page with error
// -----------------------------------------------------------------------------
router.post('/site-settings', check_login, (req, res) => {
    // get organiser id from session
    const organiser_Id = req.session.organiserid;

    // get site name and description from the form
    let { site_name, site_description } = req.body;

    // Get current settings from database
    db.get("SELECT * FROM Site_Settings WHERE organiser_id = ?", [organiser_Id], (error, existing_settings) => {
        // If error or no current settings
        if (error || !existing_settings) {
            // Render site settings page with error message
            return res.status(500).render('site-settings', { message: 'Fail to get current settings' });
        }

        // New site name if it is given, else keep current site name
        site_name = site_name && site_name.trim() !== "" ? site_name : existing_settings.site_name;
        
        // use site description if it is given, else keep current site description
        site_description = site_description && site_description.trim() !== "" ? site_description : existing_settings.site_description;

        // update site settings
        db.run(
            "UPDATE Site_Settings SET site_name = ?, site_description = ? WHERE organiser_id = ?",
            [site_name, site_description, organiser_Id],
            function (error) {
                // If error
                if (error) {
                    // Render site setting page with error message
                    return res.status(500).render('site-settings', { message: 'fail to update' });
                }

                // if successful, redirect organiser home page
                res.redirect('/organiser/');
            }
        );
    });
});

// -----------------------------------------------------------------------------
// GET /organiser-edit/:eventId?
// Purpose: Show event edit form for new or existing events
// Inputs: eventId from URL, organiserId from session
// Outputs: Renders organiser-edit.ejs with existing data or empty
// -----------------------------------------------------------------------------
router.get('/organiser-edit/:eventId?', check_login, (req, res) => {
    // organiser id from session
    const organiser_Id = req.session.organiserid;
    // event id from url
    const event_Id = req.params.eventId;

    // if no event id
    if (!event_Id) {
        // create new event
        return res.render('organiser-edit', {event: null,fullTicket: null, concessionTicket: null, isNewEvent: true, isPublished: false});
    }

    // Find existing event in db for this organiser
    db.get("SELECT * FROM Events WHERE Events_id = ? AND organiser_id = ?", [event_Id, organiser_Id], (error, event) => {
        // If error
        if (error || !event) {
            // Render organiser edit page with error message
            return res.status(404).render('organiser-edit', { message: 'Event not found' });
        }

        // Select all tickets for the event
        db.all("SELECT * FROM Tickets WHERE event_id = ?", [event_Id], (error, tickets) => {
            // If error
            if (error) {
                // Render organiser edit page with the error message
                return res.status(500).render('organiser-edit', { message: 'Could not take tickets from db' });
            }

            // Full ticket from tickets
            const fullTicket = tickets.find(t => t.type === 'full');

            // Concession ticket from tickets
            const concessionTicket = tickets.find(t => t.type === 'concession');

            // Show the edit page with the event and ticket data
            res.render('organiser-edit', {event, fullTicket, concessionTicket, isNewEvent: false, isPublished: event.status === 'published'});
        });
    });
});

// -----------------------------------------------------------------------------
// POST /organiser-edit/:eventId?
// Purpose: Create or update an event on form submission
// Inputs: Form details, eventId, organiserId from session
// Outputs: Creates new or updates existing event, then redirects to home
// -----------------------------------------------------------------------------
router.post('/organiser-edit/:eventId?', check_login, upload.single('uploadFile'), (req, res) => {
    //organiser id from session
    const organiser_Id = req.session.organiserid;
    //event id from params
    const event_Id = req.params.eventId;
    // current timestamp as iso string
    const current_timestamp = new Date().toISOString();
    // action whether publish, draft or save
    const change = req.body.action;
    // Get event form data
    const {title,description,full_quantity, full_price,concession_quantity, concession_price, event_date} = req.body;
    // check if image file is uploaded
    const image_upload = req.file;
    // image path for saving in db
    const path_image = image_upload ? '/uploads/' + image_upload.filename : null;
    // fomate event date 
    const event_date_format = event_date.replace('T', ' ') + ':00';
    // date object to compare event date and current date
    const date_today = new Date();
    const event_date_obj = new Date(event_date_format);

    // Validate that event date is in future
    if (event_date_obj <= date_today) {
        // Render organiser edit page with error message
        return res.status(400).render('organiser-edit', {message: "Event must be in the future"});
    }

    // If no event id, create event
    if (!event_Id) {
        // status and published at depend on the user clicking button
        const status = change === 'publish' ? 'published' : 'draft';
        const published_at = change === 'publish' ? current_timestamp : null;

        // Insert new event in db
        db.run(
            `INSERT INTO Events 
             (organiser_id, title, description, event_date, image_path, created_at, updated_at, published_at, status) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [organiser_Id, title, description, event_date_format, path_image, current_timestamp, current_timestamp, published_at, status],
            function (error) {
                // If error, render organiser edit page with error message
                if (error) return res.status(500).render('organiser-edit', { message: 'Error creating event' });

                // get id of the new event
                const new_Id = this.lastID;

                // insert tickets for the event
                db.run("INSERT INTO Tickets (event_id, type, quantity_available, price) VALUES (?, 'full', ?, ?)", [new_Id, full_quantity, full_price]);
                db.run("INSERT INTO Tickets (event_id, type, quantity_available, price) VALUES (?, 'concession', ?, ?)", [new_Id, concession_quantity, concession_price]);

                // Redirect to organiser home page 
                res.redirect('/organiser/');
            }
        );
    } else {
        // get current status and published at date
        db.get("SELECT status, published_at FROM Events WHERE Events_id = ? AND organiser_id = ?", [event_Id, organiser_Id], (error, event_existing) => {
            // If error
            if (error || !event_existing) {
                // Render organiser edit page with error message
                return res.status(404).render('organiser-edit', { message: 'Event not found' });
            }

            // New status and published at depend on the user
            let status = event_existing.status;
            let published_at = event_existing.published_at;

            // If user publish, status change and pulish at time change
            if (change === 'publish') {
                status = 'published';
                published_at = current_timestamp;
            // If user save as draft, status is draft and publish is null
            } else if (change === 'draft') {
                status = 'draft';
                published_at = null;
            }

            // SQL to update for image path and without image path
            const update_event = path_image
                ? `UPDATE Events SET title = ?, description = ?, event_date = ?, image_path = ?, updated_at = ?, status = ?, published_at = ? WHERE Events_id = ? AND organiser_id = ?`
                : `UPDATE Events SET title = ?, description = ?, event_date = ?, updated_at = ?, status = ?, published_at = ? WHERE Events_id = ? AND organiser_id = ?`;

            const params = path_image
                ? [title, description, event_date_format, path_image, current_timestamp, status, published_at, event_Id, organiser_Id]
                : [title, description, event_date_format, current_timestamp, status, published_at, event_Id, organiser_Id];

            // Run update query for the event
            db.run(update_event, params, function (error) {
                // If error render the organiser edit page with the error message
                if (error) return res.status(500).render('organiser-edit', { message: 'Error updating' });

                // Update ticket quantity and price for full and concession ticket
                db.run("UPDATE Tickets SET quantity_available = ?, price = ? WHERE event_id = ? AND type = 'full'", [full_quantity, full_price, event_Id]);
                db.run("UPDATE Tickets SET quantity_available = ?, price = ? WHERE event_id = ? AND type = 'concession'", [concession_quantity, concession_price, event_Id]);

                // Redirect to the organiser home page
                res.redirect('/organiser/');
            });
        });
    }
});

// -----------------------------------------------------------------------------
// POST /publish/:id
// Purpose: Publish a event
// Inputs: eventId from URL params, organiserId from session
// Outputs: Updates event status and redirects to organiser home or shows error
// -----------------------------------------------------------------------------
router.post('/publish/:id', check_login, (req, res) => {
    // Event if from url
    const event_Id = req.params.id;
    //organiser id from session
    const organiser_Id = req.session.organiserid;
    // current time in iso string
    const current_timestamp = new Date().toISOString();

    // SQL to update event status and set publish date
    const sql = `
        UPDATE Events 
        SET status = 'published', published_at = ? 
        WHERE Events_id = ? AND organiser_id = ?
    `;

    // SQL query to run
    db.run(sql, [current_timestamp, event_Id, organiser_Id], function (error) {
        // If error
        if (error) {
            // Render the organiser home page with the error message
            return res.status(500).render('organiser-home', { message: 'Fail to publish event' });
        }

        // If no rows updated, user not allowed or event not found
        if (this.changes === 0) {
            // render organiser home page with error message
            return res.status(403).render('organiser-home', { message: 'Event not found' });
        }

        // redirect to organiser home page
        res.redirect('/organiser/');
    });
});

// -----------------------------------------------------------------------------------------
// POST /delete/:id
// Purpose: Delete an event, tickets and bookings
// Inputs: eventId from URL params
// Outputs: Removes event, tickets, bookings and redirects to organiser home or shows error
// -----------------------------------------------------------------------------------------
router.post('/delete/:id', check_login, (req, res) => {
    // Event if from url
    const event_Id = req.params.id;

    // Delete all bookings for the event
    db.run("DELETE FROM Bookings WHERE event_id = ?", [event_Id], function (error) {
        // If error render organiser home page with error message
        if (error) return res.status(500).render('organiser-home', { message: 'Fail to delete bookings' });

        // Delete tickets related to the event
        db.run("DELETE FROM Tickets WHERE event_id = ?", [event_Id], function (error) {
            // If error, render organiser home page with error message
            if (error) return res.status(500).render('organiser-home', { message: 'Fail to delete tickets' });

            // SQL to delete the event
            db.run("DELETE FROM Events WHERE Events_id = ?", [event_Id], function (error) {
                // If error
                if (error) {
                    // Render organiser home page with error message
                    return res.status(500).render('organiser-home', { message: 'Fail to delete event' });
                }
                // Redirect to organiser home page
                res.redirect('/organiser/');
            });
        });
    });
});

// -----------------------------------------------------------------------------
// GET /bookings
// Purpose: Show all attendee bookings for events
// Inputs: organiserId from session
// Outputs: Renders organiser-bookings page with data or shows error
// -----------------------------------------------------------------------------
router.get('/bookings', check_login, (req, res) => {
    // organiser id from session
    const organiser_Id = req.session.organiserid;

    // SQL to get all the bookings and events details
    const SQL = `
        SELECT Bookings.attendee_name, Bookings.full_tickets, Bookings.concession_tickets, Bookings.booking_date, Events.title AS event_title, Events.event_date
        FROM Bookings
        JOIN Events ON Bookings.event_id = Events.Events_id
        WHERE Events.organiser_id = ?
        ORDER BY Bookings.booking_date DESC
    `;

    // SQL to get the data from db
    db.all(SQL, [organiser_Id], (error, bookings) => {
        // If error
        if (error) {
            // Render organiser booking page with error message
            return res.status(500).render('organiser-bookings', { message: 'fail to load bookings' });
        }

        // Render organiser booking page with all the bookings
        res.render('organiser-bookings', { bookings });
    });
});

module.exports = router;