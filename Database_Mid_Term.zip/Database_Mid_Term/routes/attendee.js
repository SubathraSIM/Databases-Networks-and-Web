// Import Express and create router
const express = require('express');
const router = express.Router();

// -----------------------------------------------------------------------------
// GET /
// Purpose: Get and show all published events grouped by site for attendees.
// Inputs: Not from the user, taking from the DB 
// Outputs: Renders attendee-home page with list of events by site.
// -----------------------------------------------------------------------------
router.get('/', (req, res) => {
    // SQL to get event details, site name, site description and ticket availablity
    const SQL_query = `
        SELECT 
            Events.*, 
            Site_Settings.site_name, 
            Site_Settings.site_description,
            IFNULL((SELECT quantity_available FROM Tickets WHERE event_id = Events.Events_id AND type = 'full'), 0) AS full_tickets,
            IFNULL((SELECT quantity_available FROM Tickets WHERE event_id = Events.Events_id AND type = 'concession'), 0) AS concession_tickets
        FROM Events
        JOIN Site_Settings ON Events.organiser_id = Site_Settings.organiser_id
        WHERE Events.status = 'published'
        ORDER BY Site_Settings.site_name ASC, Events.event_date ASC
    `;

    // Excute SQL
    db.all(SQL_query, [], (error, rows) => {
        // If error return error message
        if (error) return res.status(500).render('attendee-home', { message: 'Failed to load events' });

        // Group events by site_name
        const grouped_sites = {};
        for (const row of rows) {
            const key = row.site_name;
            // If site does not exist, add it with description and events
            if (!grouped_sites[key]) {
                grouped_sites[key] = {
                    description: row.site_description,
                    events: []
                };
            }
            // Push event in correct sites
            grouped_sites[key].events.push(row);
        }
        // Render the home page with the grouped event data with sites
        res.render('attendee-home', { grouped_sites });
    });
});


// -----------------------------------------------------------------------------
// GET /event/:id
// Purpose: Show the details of a one published event for attendees.
// Inputs: :event ID from URL, referrer and success from query.
// Outputs: attendee-event Page with event details and ticket information.
// -----------------------------------------------------------------------------
router.get('/event/:id', (req, res) => {
    //Event id from URL
    const event_Id = req.params.id;

    // Check if booking is done successfullly
    const success = req.query.success === 'true';

    // SQL to get event details and ticket information
    const SQL_query = `
        SELECT Events.*, 
               (SELECT quantity_available FROM Tickets WHERE event_id = Events.Events_id AND type = 'full') AS full_tickets,
               (SELECT price FROM Tickets WHERE event_id = Events.Events_id AND type = 'full') AS full_price,
               (SELECT quantity_available FROM Tickets WHERE event_id = Events.Events_id AND type = 'concession') AS concession_tickets,
               (SELECT price FROM Tickets WHERE event_id = Events.Events_id AND type = 'concession') AS concession_price
        FROM Events
        JOIN Site_Settings ON Events.organiser_id = Site_Settings.organiser_id
        WHERE Events.Events_id = ? AND Events.status = 'published'
    `;

    // Execute SQL
    db.get(SQL_query, [event_Id], (error, event) => {
        // If error return error message
        if (error || !event) {
            return res.status(404).render('attendee-event', { message: 'Event not found or not published', referrer: 'attendee', success:false, error:null });
        }

        // Default referrer is 'attendee'
        const referrer = req.query.referrer  || 'attendee';

        // Render the event page with ticket information
        res.render('attendee-event', { event, referrer, success, error });
    });
});


// ----------------------------------------------------------------------------------------------------------------
// POST /event/:id
// Purpose: Process ticket booking for an event by attendee or organiser.
// Inputs: : event ID from URL, attendee_name, full_quantity, concession_quantity referrer defaults is attendee.
// Outputs: Updates booking and ticket records, then redirects back to the home page.
// ----------------------------------------------------------------------------------------------------------------
router.post('/event/:id', (req, res) => {
    // Get id from URL
    const event_Id = req.params.id;

    // Get value from POST
    const { attendee_name, full_no_tickets, concession_no_tickets } = req.body;

    // Get referrer from querry
    const referrer = req.query.referrer || 'attendee';

    // Convert tickets to integers
    const full_number_tickets = parseInt(full_no_tickets) || 0;
    const concession_number_tickets = parseInt(concession_no_tickets) || 0;

    // If db values are null return error message
    db.get(`
        SELECT 
            IFNULL((SELECT quantity_available FROM Tickets WHERE event_id = ? AND type = 'full'), 0) AS full_available,
            IFNULL((SELECT quantity_available FROM Tickets WHERE event_id = ? AND type = 'concession'), 0) AS concession_available
        `, [event_Id, event_Id], (error, available) => {
        // If error return error message
        if (error) return res.status(500).render('attendee-event', { message: 'Error checking availability', event: null,referrer: referrer,success: false });

        // If quantity is more than the avaialble ones
        if (full_number_tickets > available.full_available || concession_number_tickets > available.concession_available) {
            // Query event details again for error message
            const SQL_query = `
                SELECT Events.*, 
                       (SELECT quantity_available FROM Tickets WHERE event_id = Events.Events_id AND type = 'full') AS full_tickets,
                       (SELECT price FROM Tickets WHERE event_id = Events.Events_id AND type = 'full') AS full_price,
                       (SELECT quantity_available FROM Tickets WHERE event_id = Events.Events_id AND type = 'concession') AS concession_tickets,
                       (SELECT price FROM Tickets WHERE event_id = Events.Events_id AND type = 'concession') AS concession_price
                FROM Events
                JOIN Site_Settings ON Events.organiser_id = Site_Settings.organiser_id
                WHERE Events.Events_id = ? AND Events.status = 'published'
            `;
            db.get(SQL_query, [event_Id], (error2, event) => {
                // If error return error message
                if (error2 || !event) {
                    return res.status(404).render('attendee-event', { message: 'Event not found or not published', success:false });
                }
                // If not enough tickets, return error
                return res.render('attendee-event', {event, error: 'Not enough tickets available', referrer, success: false });
            });
            return;
        }

        // Insert the bookings in the sql
        db.run(`
            INSERT INTO Bookings (event_id, attendee_name, full_tickets, concession_tickets, booked_by)
            VALUES (?, ?, ?, ?, ?)
        `, [event_Id, attendee_name, full_number_tickets, concession_number_tickets, referrer], function (err) {
            // If error return error message
            if (err) {
                return res.status(500).render('attendee-event', { message: 'Booking failed' });
            }

            // Update full tickets
            db.run(`UPDATE Tickets SET quantity_available = quantity_available - ? WHERE event_id = ? AND type = 'full'`, [full_number_tickets, event_Id]);

            // Update concession tickets
            db.run(`UPDATE Tickets SET quantity_available = quantity_available - ? WHERE event_id = ? AND type = 'concession'`, [concession_number_tickets, event_Id]);

            // redirect to the page
            res.redirect(`/attendee/event/${event_Id}?success=true&referrer=${referrer}`);
        });
    });
});

module.exports = router;